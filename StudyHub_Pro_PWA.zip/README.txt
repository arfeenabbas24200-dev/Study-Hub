STUDYHUB PRO

This is a Progressive Web App (PWA) designed for iPhone/iPad and modern browsers.

Features:
- English-only professional interface
- Subjects and course codes
- Lecture library with PDF attachments
- Built-in PDF viewer
- Lecture status: Unread / In Progress / Completed
- Progress tracking
- Notes per lecture
- Favorites
- Global search
- Recent lectures
- Full backup and restore, including PDFs
- Offline app shell after first load

IMPORTANT FOR iPHONE:
A PWA must be served from HTTPS (or localhost during development) to be installable as a Home Screen app.
After hosting these files on an HTTPS website, open the site in Safari:
Share -> Add to Home Screen -> Add

The ZIP itself cannot turn a local file into a native iPhone app. This package is ready to be hosted as a PWA. A true App Store application would require an iOS native wrapper and Apple signing/distribution.
